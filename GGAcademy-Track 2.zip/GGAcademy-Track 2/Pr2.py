# route_agent_tool.py — reorders today's route based on predicted fill levels
from ortools.constraint_solver import pywrapcp, routing_enums_pb2

def optimize_route(bins_to_collect: list[dict], truck_start: tuple, truck_capacity: int):
    """
    bins_to_collect: [{bin_id, lat, lon, predicted_fill_pct}, ...]
    Returns an ordered stop list minimizing distance while prioritizing
    bins forecast to overflow before the next scheduled cycle.
    """
    manager = pywrapcp.RoutingIndexManager(len(bins_to_collect) + 1, 1, 0)
    routing = pywrapcp.RoutingModel(manager)
    # distance callback + overflow-priority penalty weighting omitted for brevity
    # bins with predicted_fill_pct > 0.85 get a high priority weight
    search_params = pywrapcp.DefaultRoutingSearchParameters()
    search_params.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
    solution = routing.SolveWithParameters(search_params)
    return extract_ordered_stops(routing, manager, solution)