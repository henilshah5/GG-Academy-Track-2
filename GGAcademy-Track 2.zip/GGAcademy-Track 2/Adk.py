# adk_ecoroute.py
from google.adk.agents import Agent
from google.adk.orchestration import ParallelWorkflow

route_agent = Agent(name="RouteAgent", instruction="Optimize today's collection routes using fill forecasts.", tools=["route_optimizer_tool"])
contamination_agent = Agent(name="ContaminationWatchAgent", instruction="Flag zones with rising recycling contamination trends.", tools=["contamination_trend_tool"])
citizen_agent = Agent(name="CitizenSupportAgent", instruction="Answer resident questions about pickup schedules and recycling rules.", tools=["recycling_rag_tool", "pickup_schedule_tool"])

workflow = ParallelWorkflow(agents=[route_agent, contamination_agent, citizen_agent])
results = workflow.run(daily_context)