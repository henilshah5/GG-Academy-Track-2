# dumping_detection.py — analyzes camera stills from fixed cameras and citizen photo reports
from vertexai.generative_models import GenerativeModel, Part

model = GenerativeModel("gemini-2.5-pro")

def detect_dumping(image_uri: str, location: str) -> dict:
    image_part = Part.from_uri(image_uri, mime_type="image/jpeg")
    prompt = f"""
    This image is from a public camera near {location}. Determine if it shows
    illegal dumping (furniture, construction debris, bagged waste outside
    designated collection points). Return JSON: {{is_dumping: bool,
    confidence: float, waste_type: str, severity: "low"|"medium"|"high"}}.
    """
    response = model.generate_content([image_part, prompt])
    return response.text