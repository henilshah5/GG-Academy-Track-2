# recycling_rag.py — answers "can I recycle X?" grounded in the actual city ordinance
from vertexai.language_models import TextEmbeddingModel
from vertexai.generative_models import GenerativeModel

embed_model = TextEmbeddingModel.from_pretrained("text-embedding-005")
gemini = GenerativeModel("gemini-2.5-flash")

async def answer_recycling_question(question: str, conn) -> str:
    q_embedding = embed_model.get_embeddings([question])[0].values
    rows = await conn.fetch("""
        SELECT source_id, content FROM recycling_rule_embeddings
        ORDER BY embedding <-> $1 LIMIT 5
    """, q_embedding)
    context = "\n".join(r["content"] for r in rows)
    prompt = f"""Answer using ONLY this context, cite the ordinance section used.
Context:\n{context}\n\nQuestion: {question}"""
    return gemini.generate_content(prompt).text