# cloud_function_ingest_bin_sensor.py
# Triggered on new sensor reading batch landing in gs://ecoroute-raw/bin-sensors/
import functions_framework
from google.cloud import bigquery, storage
import json

@functions_framework.cloud_event
def ingest_bin_reading(cloud_event):
    bucket_name = cloud_event.data["bucket"]
    file_name = cloud_event.data["name"]

    blob = storage.Client().bucket(bucket_name).blob(file_name)
    readings = json.loads(blob.download_as_text())

    bq = bigquery.Client()
    rows = [{
        "bin_id": r["bin_id"], "fill_pct": r["fill_pct"],
        "reading_ts": r["timestamp"], "route_id": r["route_id"],
        "lat": r["lat"], "lon": r["lon"],
    } for r in readings]

    errors = bq.insert_rows_json("ecoroute.raw.bin_sensor_readings", rows)
    if errors:
        raise RuntimeError(f"BigQuery insert failed: {errors}")