# EcoRoute: An AI Decision Intelligence Platform for Smarter Waste Management & Cleaner Communities

**A conversational, multimodal decision-support platform for sanitation departments and residents — built on Google Cloud AI + Data**

---

## 1. The Problem, and Who Feels It

**Primary users:**
- **Marcus**, a Sanitation Operations Manager for a mid-size city (pop. ~280,000, 42 collection trucks, ~65,000 bins across residential and commercial routes).
- **Elena**, a Sustainability Officer tracking recycling contamination rates and illegal dumping hotspots for the city's climate action plan.
- **Residents**, who are frequently confused about what's recyclable, when their pickup day is, or who to report an overflowing public bin or illegal dumping site to.

**Today's reality:** Collection trucks run **fixed routes on fixed schedules**, regardless of whether a bin is half-empty or overflowing — meaning some routes are wasted fuel on nearly-empty bins while others generate resident complaints about overflow days before the scheduled pickup. Illegal dumping is only discovered when a resident happens to call it in, sometimes weeks later. Recycling contamination (food waste, plastic bags, etc. mixed into recycling) is measured manually via periodic truck-load audits — Elena finds out a neighborhood has a contamination problem months after it started. Resident questions ("is a pizza box recyclable?" "why didn't my bin get picked up?") flood a call center with long hold times.

**The cost of the gap:** Inefficient fixed routing wastes fuel and truck-hours the city budget can't spare; unreported illegal dumping sites grow and become long-term environmental and public-health hazards; residents disengage from recycling programs when their simple questions go unanswered.

---

## 2. The Decisions This Platform Supports

1. **Dynamic routing:** "Given today's actual bin-fill levels (sensor + predicted), which route order minimizes truck-miles while avoiding any overflow?"
2. **Anomaly detection:** "Is this camera image of a vacant lot showing illegal dumping — and if so, alert code enforcement immediately, not weeks later."
3. **Predictive maintenance of the recycling stream:** "Which neighborhoods are trending toward higher recycling contamination, before the next truck-load audit catches it?"
4. **Conversational citizen support:** "A resident asks 'can I recycle a greasy pizza box?' or 'when is my next pickup?' — answered instantly and correctly, in natural language, any time of day."

---

## 3. Architecture Overview

```
┌─────────────────────────┐   ┌───────────────────────┐   ┌────────────────────────────┐
│ Data Sources              │   │ Ingestion              │   │ Data & Vector Layer          │
│ - Bin fill-level sensors  │   │ Cloud Functions        │   │ BigQuery                     │
│ - Truck GPS/telematics    │──▶│ (event-driven ETL)     │──▶│ - bin fill history, routes,  │
│ - Resident 311 reports    │   │ Cloud Storage          │   │   contamination audit data   │
│ - Dumping-site camera feeds│  │ (raw + curated zones)  │   │ AlloyDB (pgvector)            │
│ - Municipal recycling rules│  │                        │   │ - embeddings of recycling     │
│   (PDF/HTML documents)     │  └───────────────────────┘   │   rules, ordinances, FAQs     │
└─────────────────────────┘                                └──────────────┬───────────────┘
                                                                            │
                          ┌─────────────────────────────────────────────────┘
                          ▼
              ┌───────────────────────────────┐        ┌───────────────────────────┐
              │ Vertex AI / Gemini Layer        │        │ Predictive & Vision Layer  │
              │ - Gemini multimodal: dumping    │        │ - BQML: bin fill-level     │
              │   detection from camera images  │◀──────▶│   forecast per bin/route   │
              │ - RAG over AlloyDB: recycling   │        │ - BQML: contamination      │
              │   rules Q&A, grounded & cited   │        │   trend detection per zone │
              │ - Agent Development Kit (ADK)   │        └───────────────────────────┘
              │   multi-agent orchestration      │
              └───────────────┬────────────────┘
                              ▼
              ┌───────────────────────────────┐
              │ Serving & Automation            │
              │ Cloud Run (chat API, route      │
              │  optimizer service, agent host) │
              │ Cloud Functions (auto-alerting, │
              │  code-enforcement ticket creation)│
              └───────────────┬────────────────┘
                              ▼
              ┌───────────────────────────────┐
              │ Decision Surfaces               │
              │ - Looker: route efficiency,     │
              │   contamination heatmap, KPIs   │
              │ - Conversational resident       │
              │   assistant (web/SMS)           │
              └───────────────────────────────┘
```

**Google Cloud components used (6):**
- **BigQuery** — unified warehouse for bin-fill sensor history, truck telematics, resident reports, and contamination audit results.
- **AlloyDB (with pgvector)** — stores embeddings of recycling ordinances, sorting-rule documents, and past resident FAQs for grounded conversational answers.
- **Vertex AI + Gemini** — powers multimodal illegal-dumping detection from camera images and the natural-language citizen assistant.
- **Agent Development Kit (ADK)** — orchestrates a *Route Agent*, a *Contamination Watch Agent*, and a *Citizen Support Agent* that each own a distinct decision.
- **Cloud Functions** — event-driven ingestion and automated code-enforcement ticket creation when dumping is confirmed.
- **Cloud Run** — hosts the route-optimization service and the always-on conversational API.
- **Cloud Storage** — raw landing zone for sensor exports, GPS logs, and camera imagery.
- **Looker** — the operational dashboard Marcus and Elena actually use each morning.

---

## 4. Data Pipeline

### Step 1 — Ingest (Cloud Functions + Cloud Storage → BigQuery)
```python
# cloud_function_ingest_bin_sensor.py
# Triggered on new sensor reading batch landing in gs://ecoroute-raw/bin-sensors/
import functions_framework
from google.cloud import bigquery, storage
import json

@functions_framework.cloud_event
def ingest_bin_reading(cloud_event):
    bucket_name = cloud_event.data["bucket"]
    file_name = cloud_event.data["name"]

    blob = storage.Client().bucket(bucket_name).blob(file_name)
    readings = json.loads(blob.download_as_text())

    bq = bigquery.Client()
    rows = [{
        "bin_id": r["bin_id"], "fill_pct": r["fill_pct"],
        "reading_ts": r["timestamp"], "route_id": r["route_id"],
        "lat": r["lat"], "lon": r["lon"],
    } for r in readings]

    errors = bq.insert_rows_json("ecoroute.raw.bin_sensor_readings", rows)
    if errors:
        raise RuntimeError(f"BigQuery insert failed: {errors}")
```

### Step 2 — Bin fill-level forecast (BigQuery ML)
```sql
-- Predict which bins will be >85% full by tomorrow's collection window
CREATE OR REPLACE MODEL ecoroute.models.bin_fill_forecast
OPTIONS(model_type='linear_reg', input_label_cols=['fill_pct_next_24h']) AS
SELECT
  bin_id, route_id, avg_fill_rate_7d, day_of_week,
  household_count_nearby, is_holiday_week, fill_pct_next_24h
FROM ecoroute.curated.bin_fill_training_features;

SELECT bin_id, route_id, predicted_fill_pct_next_24h
FROM ML.PREDICT(MODEL ecoroute.models.bin_fill_forecast,
  (SELECT * FROM ecoroute.curated.bin_fill_features_today))
WHERE predicted_fill_pct_next_24h > 0.85;
```

### Step 3 — Dynamic route optimization (Cloud Run service, ADK Route Agent)
```python
# route_agent_tool.py — reorders today's route based on predicted fill levels
from ortools.constraint_solver import pywrapcp, routing_enums_pb2

def optimize_route(bins_to_collect: list[dict], truck_start: tuple, truck_capacity: int):
    """
    bins_to_collect: [{bin_id, lat, lon, predicted_fill_pct}, ...]
    Returns an ordered stop list minimizing distance while prioritizing
    bins forecast to overflow before the next scheduled cycle.
    """
    manager = pywrapcp.RoutingIndexManager(len(bins_to_collect) + 1, 1, 0)
    routing = pywrapcp.RoutingModel(manager)
    # distance callback + overflow-priority penalty weighting omitted for brevity
    # bins with predicted_fill_pct > 0.85 get a high priority weight
    search_params = pywrapcp.DefaultRoutingSearchParameters()
    search_params.first_solution_strategy = (
        routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC)
    solution = routing.SolveWithParameters(search_params)
    return extract_ordered_stops(routing, manager, solution)
```

### Step 4 — Multimodal illegal-dumping detection (Gemini Vision)
```python
# dumping_detection.py — analyzes camera stills from fixed cameras and citizen photo reports
from vertexai.generative_models import GenerativeModel, Part

model = GenerativeModel("gemini-2.5-pro")

def detect_dumping(image_uri: str, location: str) -> dict:
    image_part = Part.from_uri(image_uri, mime_type="image/jpeg")
    prompt = f"""
    This image is from a public camera near {location}. Determine if it shows
    illegal dumping (furniture, construction debris, bagged waste outside
    designated collection points). Return JSON: {{is_dumping: bool,
    confidence: float, waste_type: str, severity: "low"|"medium"|"high"}}.
    """
    response = model.generate_content([image_part, prompt])
    return response.text
```

### Step 5 — Grounded recycling Q&A (RAG over AlloyDB)
```python
# recycling_rag.py — answers "can I recycle X?" grounded in the actual city ordinance
from vertexai.language_models import TextEmbeddingModel
from vertexai.generative_models import GenerativeModel

embed_model = TextEmbeddingModel.from_pretrained("text-embedding-005")
gemini = GenerativeModel("gemini-2.5-flash")

async def answer_recycling_question(question: str, conn) -> str:
    q_embedding = embed_model.get_embeddings([question])[0].values
    rows = await conn.fetch("""
        SELECT source_id, content FROM recycling_rule_embeddings
        ORDER BY embedding <-> $1 LIMIT 5
    """, q_embedding)
    context = "\n".join(r["content"] for r in rows)
    prompt = f"""Answer using ONLY this context, cite the ordinance section used.
Context:\n{context}\n\nQuestion: {question}"""
    return gemini.generate_content(prompt).text
```

### Step 6 — Multi-agent orchestration (ADK)
```python
# adk_ecoroute.py
from google.adk.agents import Agent
from google.adk.orchestration import ParallelWorkflow

route_agent = Agent(name="RouteAgent", instruction="Optimize today's collection routes using fill forecasts.", tools=["route_optimizer_tool"])
contamination_agent = Agent(name="ContaminationWatchAgent", instruction="Flag zones with rising recycling contamination trends.", tools=["contamination_trend_tool"])
citizen_agent = Agent(name="CitizenSupportAgent", instruction="Answer resident questions about pickup schedules and recycling rules.", tools=["recycling_rag_tool", "pickup_schedule_tool"])

workflow = ParallelWorkflow(agents=[route_agent, contamination_agent, citizen_agent])
results = workflow.run(daily_context)
```

### Step 7 — Automation (Cloud Functions)
When `detect_dumping()` returns `is_dumping: true` with confidence > 0.8, a Cloud Function automatically opens a code-enforcement ticket and geofences the location for the next patrol — no resident report required.

### Step 8 — Decision surfaces (Looker)
- **Route Efficiency dashboard** (Marcus): truck-miles saved vs. fixed-route baseline, bins-at-risk-of-overflow map.
- **Sustainability dashboard** (Elena): recycling contamination trend by zone, illegal-dumping hotspot map with auto-flagged sites.
- **Ask EcoRoute** chat widget (residents): pickup schedule lookup, recycling sorting Q&A, and a "report dumping" photo upload that feeds directly into the vision pipeline.

---

## 5. The Output People Actually Use

**Dynamic route plan (Marcus's view):**

| Stop Order | Bin ID | Predicted Fill % | Reason Prioritized |
|---|---|---|---|
| 1 | B-4471 | 94% | Forecast overflow before next cycle |
| 2 | B-4502 | 88% | Forecast overflow before next cycle |
| 3 | B-4390 | 41% | On path, low priority — collected in normal order |

**Dumping alert (auto-created ticket):**
> "Camera CAM-118 near Elm St vacant lot: possible illegal dumping detected (confidence 0.91, construction debris). Code enforcement ticket #CE-7734 auto-created, patrol dispatched."

**Conversational answer (resident):**
> Q: "Can I recycle a greasy pizza box?"
> A: "The grease-stained bottom of a pizza box should go in food/organic waste, but the clean top portion can be recycled — tear it in half. [Source: City Recycling Ordinance §4.2]"

---

## 6. Evidence of Better, Faster Decisions

| Capability | Before (manual/siloed) | With EcoRoute | Impact |
|---|---|---|---|
| Route planning | Fixed schedule regardless of actual fill level | Daily dynamic reordering based on forecast fill | Fewer overflow complaints, reduced truck-miles on near-empty bins |
| Illegal dumping discovery | Weeks, only via resident phone call | **Minutes**, automatic camera-based detection | Faster cleanup, reduced long-term environmental hazard |
| Recycling contamination visibility | Discovered via periodic manual truck-load audits (monthly) | Continuous trend detection per zone | Elena intervenes with targeted outreach before contamination becomes chronic |
| Resident question resolution | Long call-center hold times, inconsistent answers | Instant, grounded, cited answers, 24/7 | Higher recycling program participation, fewer call-center hours |

---

## 7. Responsible & Explainable AI

- The Gemini dumping-detection output includes a **confidence score**, and auto-created tickets below a configurable threshold route to human review instead of triggering enforcement action automatically.
- RAG answers about recycling rules **cite the specific ordinance section**, so residents and staff can verify the answer rather than trust an unsourced claim.
- Camera imagery used for dumping detection is limited to public rights-of-way and vacant lots, and images are not used for facial recognition or resident identification of any kind.
- Route optimization decisions are transparent and overridable — Marcus's dispatchers can manually adjust any auto-generated route before trucks leave the depot.

---

## 8. Why This Combination of Technologies

- **BigQuery + AlloyDB** together because sensor time series and route data are naturally tabular (BigQuery), while recycling ordinances and FAQs are unstructured text that needs semantic retrieval (AlloyDB pgvector) — one store can't do both well.
- **Gemini + ADK** together because dumping detection, contamination trend-watching, and citizen Q&A are three distinct decisions with distinct tools; a single agent trying to do all three in one prompt would be harder to audit and improve independently.
- **Cloud Run + Cloud Functions** together because the citizen chat and route optimizer need an always-warm scalable API, while ingestion and ticket-creation are naturally event-driven, short-lived tasks.
- **Looker** remains the single dashboard Marcus and Elena actually open each morning — everything upstream exists to keep it fast, current, and trustworthy.

---

## 9. Next Steps / How to Extend

1. Extend the vision pipeline to also classify bin contamination at the truck level (camera on the collection arm) for real-time contamination scoring instead of monthly audits.
2. Add a resident-facing mobile notification: "Your bin is forecast to overflow before pickup — consider dropping bags at the nearest drop-off point."
3. Integrate weather and event-calendar data (festivals, holidays) into the fill-forecast model to anticipate seasonal waste-volume spikes.

---

*This document is a self-contained project proposal and reference implementation outline. Code samples are illustrative and should be adapted to your actual GCP project, schema, and ADK/Vertex AI configuration before running.*
